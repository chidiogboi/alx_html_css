# CSS Advanced Project

This project is part of the ALX HTML/CSS curriculum focusing on advanced CSS techniques.

## Project Overview
- Recreate a webpage based on a Figma design
- Implement responsive design
- Use advanced CSS features

## Requirements
- HTML5
- CSS3
- Specific fonts: Source Sans Pro and Spin Cycle OT

## Setup
1. Clone this repository
2. Open index.html in a browser

